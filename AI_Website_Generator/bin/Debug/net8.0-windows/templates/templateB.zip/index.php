<?php /* Generated Template */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creative Agency</title>
    <link rel="stylesheet" href="/templates/styleB.css">
</head>
<body>
    <header>
        <h1>Creative Agency</h1>
        <p>We bring your ideas to life</p>
    </header>
    <section class="portfolio">
        <h2>Our Work</h2>
        <div class="project">Project 1</div>
        <div class="project">Project 2</div>
        <div class="project">Project 3</div>
    </section>
    <footer>
        <p>� 2025 Creative Agency</p>
    </footer>
</body>
</html>
<style>
    /* General Styles */
    body {
        font-family: 'Poppins', Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: #f8f9fa;
        color: #333;
        text-align: center;
    }

    /* Header */
    header {
        background: linear-gradient(135deg, #e74c3c, #ff6b6b);
        padding: 40px;
        color: white;
        font-size: 1.8em;
        font-weight: bold;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        border-radius: 0 0 15px 15px;
    }

    /* Portfolio Section */
    .portfolio {
        margin: 40px auto;
        padding: 20px;
        max-width: 900px;
    }

        .portfolio h2 {
            font-size: 2em;
            color: #2c3e50;
            margin-bottom: 20px;
        }

    /* Project Cards */
    .project {
        display: inline-block;
        background: #f39c12;
        padding: 20px;
        margin: 15px;
        width: 250px;
        border-radius: 12px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        font-weight: bold;
        color: white;
        transition: transform 0.2s ease-in-out, box-shadow 0.3s ease-in-out;
    }

        .project:hover {
            transform: translateY(-5px);
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.15);
            background: #e67e22;
        }

    /* Footer */
    footer {
        background: #2c3e50;
        color: white;
        padding: 15px;
        font-size: 1em;
        border-radius: 15px 15px 0 0;
        box-shadow: 0px -4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .portfolio {
            padding: 10px;
        }

        .project {
            width: 90%;
            margin: 10px auto;
        }
    }

</style>