<?php
                                    /* Template: Template C */
                                    ?><!DOCTYPE html>
                                    <html>
                                    <head>
                                        <meta charset='UTF-8'>
                                        <title>Template C</title>
                                    </head>
                                    <body>
                                    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Store</title>
    <link rel="stylesheet" href="stylesC.css">
</head>
<body>
    <header>
        <h1>Shop With Us</h1>
    </header>

    <section class="products">
        <div class="product-card">
            <h3>Product 1</h3>
            <p>$19.99</p>
            <button>Buy Now</button>
        </div>
        <div class="product-card">
            <h3>Product 2</h3>
            <p>$29.99</p>
            <button>Buy Now</button>
        </div>
        <div class="product-card">
            <h3>Product 3</h3>
            <p>$39.99</p>
            <button>Buy Now</button>
        </div>
        <div class="product-card">
            <h3>Product 4</h3>
            <p>$49.99</p>
            <button>Buy Now</button>
        </div>
    </section>

    <footer>
        <p>© 2025 ShopWithUs</p>
    </footer>
</body>
</html>

<style>
    /* General Styles */
    body {
        font-family: 'Poppins', Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: #f5f5f5;
        color: #333;
        text-align: center;
    }

    /* Header */
    header {
        background: linear-gradient(135deg, #27ae60, #2ecc71);
        padding: 30px;
        color: white;
        font-size: 1.8em;
        font-weight: bold;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Product Grid */
    .products {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        padding: 40px;
        max-width: 1000px;
        margin: auto;
    }

    /* Product Cards */
    .product-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: transform 0.2s ease-in-out, box-shadow 0.3s ease-in-out;
    }

        .product-card h3 {
            font-size: 1.4em;
            color: #2c3e50;
        }

        .product-card p {
            font-size: 1.2em;
            color: #27ae60;
            font-weight: bold;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.15);
        }

    /* Buy Now Button */
    button {
        background: #e74c3c;
        color: white;
        padding: 10px 20px;
        border: none;
        font-size: 1em;
        border-radius: 25px;
        cursor: pointer;
        transition: background 0.3s ease-in-out, transform 0.2s ease-in-out;
    }

        button:hover {
            background: #c0392b;
            transform: scale(1.05);
        }

    /* Footer */
    footer {
        background: #2c3e50;
        color: white;
        padding: 15px;
        font-size: 1em;
        border-radius: 15px 15px 0 0;
        box-shadow: 0px -4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .products {
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            padding: 20px;
        }

        button {
            width: 100%;
        }
    }
</style>
                                    </body>
                                    </html>